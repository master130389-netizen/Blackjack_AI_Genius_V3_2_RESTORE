# === CONFIGURAZIONE GLOBALE ===

# --- TELEGRAM ---
TELEGRAM_TOKEN = "7968068612:AAEg-Dg7Zw_m3fhd26e51nZb6lB2SMGwsmk"   # <-- il tuo token
TELEGRAM_CHAT_ID = "8581750466"                                     # <-- il tuo chat_id

# --- CARTELLE ---
LOG_FOLDER    = "logs"
BACKUP_FOLDER = "backups"
DATA_FOLDER   = "data"

# --- FILE STANDARD ---
ERROR_LOG_FILE = "error_log.txt"
TRAINING_FILE  = "training_log.json"
FEEDBACK_CSV   = "feedback_log.csv"

# --- BACKUP ---
AUTO_BACKUP_INTERVAL_HOURS = 12
